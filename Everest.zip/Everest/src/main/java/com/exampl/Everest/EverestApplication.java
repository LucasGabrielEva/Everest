package com.exampl.Everest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverestApplication.class, args);
	}

}
